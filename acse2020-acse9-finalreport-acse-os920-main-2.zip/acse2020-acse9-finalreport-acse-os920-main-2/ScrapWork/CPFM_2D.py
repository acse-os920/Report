print("You have selected the 2D CPFM simulation.")

from IPython import display
import numpy as np
import scipy.sparse
import matplotlib.pyplot as plt
from matplotlib import cm
import scipy.sparse.linalg
import math

######################
## Helper Functions ##
######################
def laplace_matrix_2D_RD(Nx, Ny):
    """
    Creates the 2D Laplacian discretization matrix for a rectangular domain,
        thereby allowing for cases where Nx =/= Ny 
    Input: Nx & Ny (int), number of grid points on x- & y-axes
    Output: A_matrix (float array), 2D Laplacian discretization matrix
    """
    # initialize the Laplacian discretization matrix
    A_matrix = np.zeros((Nx*Ny, Nx*Ny))
    
    # iterate over the main diagonal
    for i in range(Nx*Ny):
        
        A_matrix[i][i] = -4 # coefficient for current cell x_i,j 
        
        if (i > 0):
            A_matrix[i-1][i] = 1 # coefficient for right neighbor x_i+1,j 
            
            if (((i + 1) % Ny == 1) and (i < Nx * Ny - 1)):
                A_matrix[i-1][i] = 0 # remove non-existent right neighbor x_i+1,j 
                                        # when reaching the end of a row       
        if (i < Nx * Ny) and (i > 0):
            A_matrix[i][i-1] = 1 # coefficient for left neighbor x_i-1,j 
            
        if (((i + 1) % Ny == 1) and (i > 2)):
            A_matrix[i][i-1] = 0 # remove non-existent left neighbor x_i-1,j 
                                        # when reaching the end of a row
                
    # np.diag() to add coefficients for top (x_i,j-1) and bottom (x_i,j+1) neighbors respectively       
    A_matrix += np.diag(np.ones(Nx * Ny - Ny), -Ny) + np.diag(np.ones(Nx * Ny - Ny), Ny)
  
    return A_matrix


def gradient_finder_2D(func):
    """
    Finds the d/dx and d/dy gradient fields of a 2D function/matrix
    NOTE : Identical to what numpy.gradient() does, however serves as
        a proof of concept for the C++ implementation
    NOTE : numpy.hstack() & .vstack() used for convenience, would be 
        replaced by simple loops in C++
    Inputs: func (float array), (Nx) x (Ny) array with entries representing function
        values for which d/dx and d/dy will be calculated
    Output: dx_func & dy_func (float array), (Nx) x (Ny) dfunc/dx & dfunc/dy arrays    
    """
    # calculate the x-derivative
        # cells in the middle have the average of the left- and right- derivatives
    x_difference = func[:, 1:]  - func[:, :-1] # defined as x_i+1,j - x_i,j
    dx_func = np.hstack((np.transpose(np.array([x_difference[:,0]])), 0.5 * (x_difference[:,1:] + x_difference[:,:-1]), np.transpose(np.array([x_difference[:,-1]]))))
    
    # calculate the y-derivative
        # cells in the middle have the average of the down- and up- derivatives
    y_difference = func[1:, :]  - func[:-1, :] # defined as x_i,j+1 - x_i,j
    dy_func = np.vstack(((np.array([y_difference[0,:]])), 0.5 * (y_difference[1:,:] + y_difference[:-1,:]), (np.array([y_difference[-1,:]]))))
    
    return dx_func, dy_func # return 2D dfunc/dx & dfunc/dy arrays   


######################
## Update Functions ##
######################
def rho_update_2D(n_alpha, q_alpha):
    """
    Updates / computes rho^k (rho at the current time-step)
    Input: n_alpha (float array), (alpha) x (Nx) x (Ny) array storing current n_alpha
               grid values for each respective species alpha
           q_alpha (int array), each entry represents charge of a species
    Output: rho (float array), (Nx) x (Ny) charge density array
    """
    # initialize rho to Nx x Ny size, bypass the 1st array dimension
    rho = np.zeros(np.shape(n_alpha)[1:]) 
    
    # iterate over the alphas
    for i in range(np.shape(n_alpha)[0]):
        
        rho += n_alpha[i] * q_alpha[i] # update / compute rho
        
    return rho # return 2D rho array


def phi_update_2D(a, Nx, Ny, A_matrix, rho, epsilon_0, epsilon_r): 
    """
    Updates / computes phi^k (phi at the current time-step) via
        solving Poisson's equation
    Input: a (float), a = dx = dy
           Nx & Ny (int), number of grid points on x- & y-axes
           A_matrix (float array), 2D Laplacian discretization matrix
           rho (float array), (Nx) x (Ny) charge density array
           epsilon_0 & epsilon_r (float), constants
    Output: phi (float array), (Nx) x (Ny) electric potential array
    """
    
    c_rho = a**2 * np.exp(1)**2 / (2.0 * epsilon_0 * epsilon_r) # store the constant for the RHS vector

    rho_vec = rho.flatten() # from 2D to 1D
    
    # use GMRES to solve for phi^k (until you explore solver efficiency!!!!)
    phi = scipy.sparse.linalg.gmres(-A_matrix, c_rho * rho_vec)[0]
    
    return phi.reshape((Nx, Ny)) # return 2D phi array


def mu_bar_alpha_update_2D(a, Nx, Ny, theta, mu_bar_alpha_0, mu_bar_alpha_1, A_alpha, epsilon): 
    """
    Updates / computes mu_bar_alpha^k (mu_bar_alpha at the current time-step)
    Input: a (float), a = dx = dy
           Nx & Ny (int), number of grid points on x- & y-axes
           theta (float array), (Nx * Ny) array representing the flattened 2D phase
           mu_bar_alpha_0 & mu_bar_alpha_1 (float array), (alpha) x (Nx * Ny) mu_bar_alpha
               chemical potential arrays for the purely solid and liquid phases respectively
           A_alpha (float array), each entry represents a constant for a species
           epsilon (float), a constant scaling theta's gradient contribution 
    Output: mu_bar_alpha (float array), (alpha) x (Nx) x (Ny) electrochemical potential array
    """
    mu_bar_alpha = np.zeros(np.shape(mu_bar_alpha_0)) # initialize mu_bar_alpha as a 2D alpha x Nx*Ny array
    
    # store the f(theta) expression
    f_theta = theta**2 * (1 - theta)**2
    
    # store the h(theta) expression
    h_theta = theta**2 * (3 - 2 * theta)
   
    # store the gradient of theta expression (independent of alpha)
    dtheta_dx, dtheta_dy = gradient_finder_2D(0.5 * epsilon**2 * theta.reshape([Nx, Ny]))
    
    for i in range(np.shape(mu_bar_alpha_0)[0]): # iterate over the alphas
        
        # update / compute mu_bar_alpha
        mu_bar_alpha[i] = mu_bar_alpha_0[i] + (mu_bar_alpha_1[i] - mu_bar_alpha_0[i]) * h_theta - 0.5 * A_alpha[i] * f_theta + 0.5 * epsilon**2 * (dtheta_dx.flatten()**2 + dtheta_dy.flatten()**2) 
        
    return mu_bar_alpha.reshape((np.shape(mu_bar_alpha_0)[0], Nx, Ny)) # return as a 3D alpha x Nx x Ny array
                                                                        # for easier use in mu_alpha_update()
    

def theta_update_2D(dt, a, Nx, Ny, n_alpha, theta, A_matrix, A_alpha, mu_bar_alpha_0, mu_bar_alpha_1, M, epsilon):
    """
    Updates / computes theta^(k+1) (theta at the future time-step) via 
        forward in time discretization
    Input: dt (float), size of time-step, dt
           a (float), a = dx = dy
           Nx & Ny (int), number of grid points on x- & y-axes
           n_alpha (float array), (alpha) x (Nx) x (Ny) array storing current n_alpha
               grid values for each respective species alpha
           theta^k (float array), (Nx * Ny) array representing the flattened 2D phase
           A_matrix (float array), 2D Laplacian discretization matrix
           A_alpha (float array), each entry represents a constant for a species
           mu_bar_alpha_0 & mu_bar_alpha_1 (float array), (alpha) x (Nx * Ny) mu_bar_alpha
               arrays for the purely solid and liquid phases respectively
           M (float), a constant 
           epsilon (float), a constant scaling theta's Laplacian contribution 
    Output: theta^(k+1) (float array), (Nx * Ny) array representing the flattened 2D phase
    """
    # initialize dtheta/dt
    dtheta_dt = np.zeros(np.shape(theta))
    
    # calculate & store h'(theta) and f'(theta)
    df_dt = theta * (1 - theta) * (1 - 2 * theta)
    dh_dt = 6 * theta * (1 - theta)
    
    # save the result of the matrix-vector product 
    A_theta = A_matrix @ theta 
    A_theta = np.pad((A_theta.reshape([Nx,Ny])[1:-1,1:-1]), 1)
    
    # Neumann BCs for edges
    for i in range(1,Nx):
        A_theta[i,0] = A_theta[i,1]       # left BC
        A_theta[i,Nx-1] = A_theta[i,Nx-2] # right BC
    for i in range(1,Ny):
        A_theta[0,i] = A_theta[1,i]       # top BC
        A_theta[Ny-1,i] = A_theta[Ny-2,i] # bottom BC
    A_theta[0,0] = 0.5 * (A_theta[0,1] + A_theta[1,0])                   # top left BC
    A_theta[0,Nx-1] = 0.5 * (A_theta[0,Nx-2] + A_theta[1,Nx-1])          # top right BC
    A_theta[Ny-1,0] = 0.5 * (A_theta[Ny-1,1] + A_theta[Ny-2,0])          # bottom left BC
    A_theta[Ny-1,Nx-1] = 0.5 * (A_theta[Ny-1,Nx-2] + A_theta[Ny-2,Nx-1]) # top left BC
    
    # from 2D to 1D storage
    A_theta = A_theta.flatten() 
        
    # sum over the alphas
    for i in range(np.shape(mu_bar_alpha_0)[0]):
        
        dtheta_dt += n_alpha[i].flatten() * ((mu_bar_alpha_1[i] - mu_bar_alpha_0[i]) * dh_dt - A_alpha[i] * df_dt + epsilon**2 * A_theta)
        
    # take a theta time-step
    theta += dt * M * dtheta_dt
    
    return theta


def mu_and_v_alpha_update_2D(a, k_B, T, mu_bar_alpha, q_alpha, phi, D_alpha):
    """
    Input: a (float), a = dx = dy
           mu_bar_alpha (float array), (alpha) x (Nx) x (Ny) chemical potential array
           q_alpha (int array), each entry represents charge of a species
           phi (float array), (Nx) x (Ny) electric potential array
           D_alpha (float array), (alpha) x (Nx) x (Ny) diffusion coefficient array
    Output: mu_alpha (float array), (alpha) x (Nx) x (Ny) electrochemical potential array
            v_alpha (float array), (alpha) x (Nx) x (Ny) velocity array
    """
    # initialize mu_alpha
    mu_alpha = np.zeros(np.shape(mu_bar_alpha))

    # initialize v_alpha
    v_alpha = np.zeros(np.shape(mu_bar_alpha))

    # Note : we want to store the exponential expression relating mu_alpha to J_alpha
        # to minimize computational cost by minimizing the np.exp() calls. This will 
        # become evident in the J_alpha_update_2D() function.
    
    c = 2 * k_B * T # store constant
    
    for i in range(len(q_alpha)): # loop over 1st dimension (layer) of 3D mu_alpha & v_alpha tensors
    
        # equivalent to mu_alpha = np.exp(mu_alpha/c)   
        mu_alpha[i] = np.exp((mu_bar_alpha[i] + q_alpha[i] * phi)/c)

        v_alpha[i] = (1.0/a) * D_alpha[i]
          
    return mu_alpha, v_alpha # both returned as 3D alpha x Na x Na arrays
     

def J_alpha_update_2D(mu_alpha, v_alpha, n_alpha):
    """
    Computes the precursor to dn_alpha/dt, J_alpha_UMat
    Input: T (float), temperature
           k_B (float), Boltzmann's constant 
           mu_alpha (float array), (alpha) x (Nx) x (Ny) electrochemical potential array 
           v_alpha (float array), (alpha) x (Nx) x (Ny) velocity array
           n_alpha (float array), (alpha) x (Nx) x (Ny) array storing current n_alpha
               grid values for each respective species alpha
    Output: J_alpha_UMat (float array), (alpha) x (Nx) x (Ny) particle current update array
    """
    
    # initialize J_alpha_UMat to have m x (Na) x (Na) dimensions
    J_alpha_UMat = np.zeros((np.shape(n_alpha)[0], np.shape(n_alpha)[1], np.shape(n_alpha)[2]))
    # Our update matrix which we will simply scale and then add on n_alpha_Current !!! Pretty COOL !
    
    # Our axes : +-----> (x-axis)
    #            |
    #            |
    #            v (y-axis)
    # each cell n_alpha has 4 possible neighbors, left, right, top, bottom
        # all of these neighbors exchange information to form dn/dt
        # NOTE: some cells have 2 (corner) or 3 (edge) neighbors which needs to be accounted for
    
    # now iterate over each grid index, update J_alpha_UMat values for all alphas each iteration
    
    # 1st : Deal with the Interior (Na - 2) x (Na - 2) domain
    for i in range(1, np.shape(n_alpha)[1] - 1):
        for j in range(1, np.shape(n_alpha)[2] - 1):
            
            # signs given to be positive if flow into cell i,j
            J_left = v_alpha[:,i-1,j] * n_alpha[:,i-1,j] * mu_alpha[:,i-1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i-1,j]
            J_right = v_alpha[:,i+1,j] * n_alpha[:,i+1,j] * mu_alpha[:,i+1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i+1,j]
            J_top = v_alpha[:,i,j-1] * n_alpha[:,i,j-1] * mu_alpha[:,i,j-1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j-1]
            J_bottom = v_alpha[:,i,j+1] * n_alpha[:,i,j+1] * mu_alpha[:,i,j+1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j+1]
            
            J_alpha_UMat[:,i,j] = J_left + J_right + J_top + J_bottom
            
    
    # 2nd : Deal with the Edges
    for j in range(1, np.shape(n_alpha)[2] - 1):
        
        # left column
        i = 0
        J_right = v_alpha[:,i+1,j] * n_alpha[:,i+1,j] * mu_alpha[:,i+1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i+1,j]
        J_top = v_alpha[:,i,j-1] * n_alpha[:,i,j-1] * mu_alpha[:,i,j-1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j-1]
        J_bottom = v_alpha[:,i,j+1] * n_alpha[:,i,j+1] * mu_alpha[:,i,j+1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j+1]
        J_alpha_UMat[:,i,j] = J_top + J_bottom + J_right # left column 
    
        # right column
        i = np.shape(n_alpha)[1] - 1
        J_left = v_alpha[:,i-1,j] * n_alpha[:,i-1,j] * mu_alpha[:,i-1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i-1,j]
        J_top = v_alpha[:,i,j-1] * n_alpha[:,i,j-1] * mu_alpha[:,i,j-1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j-1]
        J_bottom = v_alpha[:,i,j+1] * n_alpha[:,i,j+1] * mu_alpha[:,i,j+1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j+1]
        J_alpha_UMat[:,i,j] = J_top + J_bottom + J_left # right column 
    
    for i in range(1, np.shape(n_alpha)[1] - 1):
    
        # top row
        j = 0
        J_left = v_alpha[:,i-1,j] * n_alpha[:,i-1,j] * mu_alpha[:,i-1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i-1,j]
        J_right = v_alpha[:,i+1,j] * n_alpha[:,i+1,j] * mu_alpha[:,i+1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i+1,j]
        J_bottom = v_alpha[:,i,j+1] * n_alpha[:,i,j+1] * mu_alpha[:,i,j+1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j+1]
        J_alpha_UMat[:,i,j] = J_left + J_right + J_bottom
       
        # bottom row
        j = np.shape(n_alpha)[2] - 1
        J_left = v_alpha[:,i-1,j] * n_alpha[:,i-1,j] * mu_alpha[:,i-1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i-1,j]
        J_right = v_alpha[:,i+1,j] * n_alpha[:,i+1,j] * mu_alpha[:,i+1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i+1,j]
        J_top = v_alpha[:,i,j-1] * n_alpha[:,i,j-1] * mu_alpha[:,i,j-1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j-1]
        J_alpha_UMat[:,i,j] = J_left + J_right + J_top   
    
    # 3rd : Deal with the Corners
    
    # top left corner
    i = 0
    j = 0
    J_right = v_alpha[:,i+1,j] * n_alpha[:,i+1,j] * mu_alpha[:,i+1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i+1,j]
    J_bottom = v_alpha[:,i,j+1] * n_alpha[:,i,j+1] * mu_alpha[:,i,j+1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j+1]
    J_alpha_UMat[:,i,j] = J_bottom + J_right 
    
    # top right corner
    i = np.shape(n_alpha)[1] - 1
    j = 0
    J_left = v_alpha[:,i-1,j] * n_alpha[:,i-1,j] * mu_alpha[:,i-1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i-1,j]
    J_bottom = v_alpha[:,i,j+1] * n_alpha[:,i,j+1] * mu_alpha[:,i,j+1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j+1]
    J_alpha_UMat[:,i,j] = J_bottom + J_left
    
    # bottom left corner
    i = 0
    j = np.shape(n_alpha)[2] - 1
    J_right = v_alpha[:,i+1,j] * n_alpha[:,i+1,j] * mu_alpha[:,i+1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i+1,j]
    J_top = v_alpha[:,i,j-1] * n_alpha[:,i,j-1] * mu_alpha[:,i,j-1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j-1] 
    J_alpha_UMat[:,i,j] = J_top + J_right
    
    # bottom right corner
    i = np.shape(n_alpha)[1] - 1
    j = np.shape(n_alpha)[2] - 1
    J_left = v_alpha[:,i-1,j] * n_alpha[:,i-1,j] * mu_alpha[:,i-1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i-1,j]
    J_top = v_alpha[:,i,j-1] * n_alpha[:,i,j-1] * mu_alpha[:,i,j-1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j-1]
    J_alpha_UMat[:,i,j] = J_top + J_left
    
    return J_alpha_UMat


def n_alpha_update_Forward_2D(dt, a, n_alpha, J_alpha_UMat):
    """
    Updates / computes n_alpha^(k+1) (n_alpha at the future time-step) via 
        forward in time discretization
    Input: dt (float), size of time-step, dt
           a (float), a = dx = dy
           n_alpha (float array), (alpha) x (Nx) x (Ny) array storing current n_alpha
               grid values for each respective species alpha
           J_alpha_UMat (float array), (alpha) x (Nx) x (Ny) particle current update array
    Output: n_alpha^(k+1) (float array), (alpha) x (Nx) x (Ny) array storing updated n_alpha
               grid values for each respective species alpha
    """
    # take a time-step for n_alpha
    n_alpha += (dt / a) * J_alpha_UMat
    
    return n_alpha


########################
## Iteration Function ##
########################
def iteration_Forward_2D(dt, i_glob, a, Nx, Ny, T, k_B, A_matrix, q_alpha, theta, n_alpha, mu_bar_alpha_0, mu_bar_alpha_1, D_alpha, A_alpha, M, epsilon, epsilon_0 = 1, epsilon_r = 1):
    """
    Performs an iteration via forward in time discretization
    Input: dt (float), size of time-step, dt
           i_glob (int), global iteration counter (UNUSED VARIABLE)
           a (float), a = dx = dy
           Nx & Ny (int), number of grid points on x- & y-axes
           T (float), temperature
           k_B (float), Boltzmann's constant 
           A_matrix (float array), 2D Laplacian discretization matrix
           q_alpha (int array), each entry represents charge of a species
           theta (float array), (Nx * Ny) array representing the flattened 2D phase
           n_alpha (float array), (alpha) x (Nx) x (Ny) array storing current n_alpha
               grid values for each respective species alpha
           mu_bar_alpha_0 & mu_bar_alpha_1 (float array), (alpha) x (Nx * Ny) mu_bar_alpha
               chemical potential arrays for the purely solid and liquid phases respectively
           D_alpha (float array), (alpha) x (Nx) x (Ny) diffusion coefficient array
           A_alpha (float array), each entry represents a constant for a species
           M & epsilon & epsilon_0 & epsilon_r (float), constants
    Output: n_alpha^(k+1) (float array), (alpha) x (Nx) x (Ny) array storing updated n_alpha
               grid values for each respective species alpha
            theta^(k+1) (float array), (Nx * Ny) array representing the flattened 2D phase
            mu_alpha (float array), (alpha) x (Nx) x (Ny) electrochemical potential array
    """
    # update rho
    rho = rho_update_2D(n_alpha, q_alpha)
    
    # update phi
    phi = phi_update_2D(a, Nx, Ny, A_matrix, rho, epsilon_0, epsilon_r)
    
    # update mu_bar_alpha
    mu_bar_alpha = mu_bar_alpha_update_2D(a, Nx, Ny, theta, mu_bar_alpha_0, mu_bar_alpha_1, A_alpha, epsilon)
    
    # update theta (phase) - update after calculating mu_bar_alpha with the current theta
    theta = theta_update_2D(dt, a, Nx, Ny, n_alpha, theta, A_matrix, A_alpha, mu_bar_alpha_0, mu_bar_alpha_1, M, epsilon)
    
    # update mu_alpha & v_alpha, N O T E : combined mu_alpha_update_1D and v_alpha_update_1D into ONE function
    mu_alpha, v_alpha = mu_and_v_alpha_update_2D(a, k_B, T, mu_bar_alpha, q_alpha, phi, D_alpha)
    
    # update J_alpha
    J_alpha_UMat = J_alpha_update_2D(mu_alpha, v_alpha, n_alpha)
    
    # update n_alpha
    n_alpha = n_alpha_update_Forward_2D(dt, a, n_alpha, J_alpha_UMat)
   
    return n_alpha, theta, mu_alpha


#########################
## Simulation Function ## STILL NEEDS WORK !!!
#########################
def simulation_Forward_2D(dt, tmax, Nx, Ny, T, k_B, theta, n_alpha, q_alpha, mu_bar_alpha_0, mu_bar_alpha_1, D_alpha, A_alpha, plotting = False, epsilon_r = 1, epsilon_0 = 1, epsilon = 1, M = 100000): # dt, Na, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1
    
    i_glob = 0 # global iteration counter (specifically for 1st timestep's n'(x, t) calculation)
    t_cur = 0.0  # global time counter
    
    a = 1.0/np.max((Nx,Ny)) # calculate dx
    
    A_x = np.arange(0, 1 + 1e-15, a)         # length of Na + 1
    B_x = np.arange(a/2, 1 - a/2 + 1e-15, a) # length of Na
    
    # initialize 
    n_plotting = np.array([])
    
    # construct the 2D Laplacian discretization matrix A
    A_matrix = laplace_matrix_2D_RD(Nx, Ny)
    
    # store theta as a 1D array, return as 2D array
    theta = theta.flatten()
    
    # start plotting/animating
    fig = plt.figure() # initialize figure
    axis = plt.axes(xlim =(0, 1), ylim =(-2, 10)) # marking the x-axis and y-axis 
    line, = axis.plot([], [], lw = 3) # initializing a line variable 
    plt.close() # to not have a stray plot
    
    # data which the line will 
    # contain (x, y) 
    def init(): 
        line.set_data([], []) 
        return line, 
    
    def animate(i): 
        x = np.arange(a/2, 1 - a/2 + 1e-15, a) # set the x axis to B_x

        if (i < int(tmax/dt - 1e-15)):
            
            n_plot = n_plot_matrix[i,:] # extract the i^th row for plotting
        
            line.set_data(x, n_plot) 
            
        else:
            
            return line,
      
        return line,
    
    
    while (t_cur < tmax):
        
        n_alpha, theta, mu_alpha = iteration_Forward_2D(dt, i_glob, a, Nx, Ny, T, k_B, A_matrix, q_alpha, theta, n_alpha, mu_bar_alpha_0, mu_bar_alpha_1, D_alpha, A_alpha, M, epsilon, epsilon_0 = 1, epsilon_r = 1)
        
        if (plotting):
            
            n_plotting = np.append(n_plotting, n_alpha)
                     
        i_glob += 1
        t_cur += dt
        
    if (plotting):
        
        n_plot_matrix = n_plotting.reshape((int(tmax/dt - 1e-15) + 1, len(B_x))) # every row corresponds to N_alpha 
                                                                 # at a different time-step  
        anim = FuncAnimation(fig, animate, init_func = init, frames = 500, interval = 20, blit = True)
        
        #return HTML(anim.to_jshtml())
        
        return anim
    
    else:
        
        print('\nSimulation completed at time', t_cur, '!!!')
        
        return n_alpha, theta.reshape((Nx, Ny)), mu_alpha, t_cur
    