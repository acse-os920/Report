print("You have selected the 1D CPFM simulation.")

from IPython import display
import numpy as np
import scipy.sparse
import matplotlib.pyplot as plt
from matplotlib import cm
import scipy.sparse.linalg
import math

def B_construct_1D(Na, ghosts_included = True):
    """
    Input: Na (int), number of grid points
           ghosts_included (bool), default is True (B is (Na-2) x (Na-2) and rho is Na-2)
                                           if False (B is (Na) x (Na) and rho is Na)
    Output: B (float array), 1D Poisson discretization matrix
    """
    # construct the tridiagonal Poisson discretization matrix B
    if (ghosts_included):
        
        offsets = [-1, 0, 1] 
        diags = []
        diags.append(-np.ones(Na-3)) 
        diags.append(2 * np.ones(Na-2))
        diags.append(-np.ones(Na-3))
        B = scipy.sparse.diags(diags, offsets, format='csr') # construct a CSR version of B
        B = B.toarray() # this function will only be called once so CSR not too important
        #print('The shape of B is', np.shape(B))
        #print('\nB is \n', B)        
    else:    
        offsets = [-1, 0, 1] 
        diags = []
        
        diags.append(-np.ones(Na-3)) 
        diags.append(2 * np.ones(Na-2))
        diags.append(-np.ones(Na-3))
        B = scipy.sparse.diags(diags, offsets, format='csr') # construct a CSR version of B
        B = B.toarray() # this function will only be called once so CSR not too important
        B = np.pad(B, [1, 1], mode='constant')
        B[0][0] = 1
        B[np.shape(B)[0]-1][np.shape(B)[0]-1] = 1
        #print('The shape of B is', np.shape(B))
        #print('\nB is \n', B)

    return B
    
    
def rho_update_1D(Na, n_alpha, q_alpha):
    """
    Input: Na (int), number of grid points
           n_alpha (float array), (Na + 1) x (alpha) where each column vector represents 
               n values for one alpha
           q_alpha (int array), each entry represents charge of a species
    Output: rho (float array), charge density array
    """
    
    # TREATING n_alpha as an Na x alpha matrix and q_alpha as an alpha x 1 column vector
    # ==> rho = n_alpha @ q_alpha is then the Na x 1 charge density column vector
    rho = n_alpha @ q_alpha
 
    return rho
   
    
def phi_update_1D(Na, B_matrix, rho, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1): 
    # epsilon_0 and epsilon_r expected to be global variables with possibility of epsilon_r(x) vector 
    """
    Input: Na (int), number of grid points
           B_matrix (float array), 1D Poisson discretization matrix
           rho (float array), (Na + 1) x 1 vector
           ghosts_included = True default
           epsilon_0 & epsilon_r (float) constants
    Output: phi (float array), charge density array
    """

    a = 1.0/Na # calculate dx

    ############
    # Question # Is it better to have the a^2 term scale B or rho ???? 
    ############

    c_rho = a**2 * np.exp(1)**2 / (2.0 * epsilon_0 * epsilon_r)
    
    if (ghosts_included):
        
        rho_vec = rho[1:-1] # remove boundaries/ghosts
        phi_soln = scipy.sparse.linalg.cg(B_matrix, c_rho * rho_vec)[0]
        phi = np.insert(phi_soln, 0, 0)   # add left boundary/ghost
        phi = np.insert(phi, len(phi), 0) # add right boundary/ghost
        
    else:
        
        #rho = np.insert(rho, 0, 0)
        #rho = np.insert(rho, len(rho), 0)
        #print(len(rho))
        
        phi = scipy.sparse.linalg.cg(B_matrix, c_rho * rho)[0]
        
        #rho = rho[1:-1]
        #phi = phi[1:-1]
        
    return phi


def mu_and_v_alpha_update_1D(Na, mu_bar_alpha, q_alpha, phi, D_alpha):
    """
    Input: Na (int), number of grid points
           mu_bar_alpha (float array), (Na) x (alpha) where each column vector represents 
               mu values for one alpha
           q_alpha (int array), each entry represents charge of a species
           phi (float array), (Na) x 1 electric field vector
           D_alpha (float array), (Na) x (alpha) where each column vector represents 
               D values for one alpha
    Output: mu_alpha (float array), mobility array
            v_alpha (float array), velocity array
    """

    a = 1.0/Na # calculate dx

    # initialize mu_alpha
    mu_alpha = np.zeros((np.shape(mu_bar_alpha)[0], np.shape(mu_bar_alpha)[1]))

    # initialize v_alpha
    v_alpha = np.zeros((np.shape(mu_bar_alpha)[0], np.shape(mu_bar_alpha)[1]))

    for i in range(len(q_alpha)): # loop over column vectors
        
        mu_alpha[:,i] = mu_bar_alpha[:,i] + q_alpha[i] * phi  # LOOK AGAIN

        v_alpha[:,i] = (1.0/a) * D_alpha[:,i]
          
    return mu_alpha, v_alpha


def J_alpha_update_1D(Na, T, k_B, mu_alpha, v_alpha, n_alpha):
    """
    Input: Na (int), number of grid points
           T (float), temperature
           mu_alpha (float array), (Na) x (alpha) 
           v_alpha (float array), (Na) x (alpha) 
           n_alpha (float array), (Na) x (alpha) 
    Output: J_alpha (float array), (Na + 1) x (alpha) particle current array
    """
    
    # initialize J_alpha to have Na+1 rows
    J_alpha = np.zeros((np.shape(mu_alpha)[0] + 1, np.shape(mu_alpha)[1]))
    
    for i in range(np.shape(mu_alpha)[0]):
        
        for alpha in range(np.shape(mu_alpha)[1]):
            
            # if/else statements check for existence of neigbors
            if (i == 0): # left neighbor
                J_1 = 0.0
            else:
                J_1 = np.exp(-(mu_alpha[i][alpha] + mu_alpha[i-1][alpha]) / (2 * k_B * T)) * (v_alpha[i-1][alpha] * n_alpha[i-1][alpha] * np.exp(mu_alpha[i-1][alpha]/(k_B * T)) 
                                                                                              - v_alpha[i][alpha] * n_alpha[i][alpha] * np.exp(mu_alpha[i][alpha]/(k_B * T))) 
                # expression for left neighbor
            
            # update J_alpha
            J_alpha[i][alpha] = J_1 
            
            # J_alpha(0) = 0, left BC
            J_alpha[0, :] = 0
            
            # J_alpha(Na+1) = 0, right BC
            J_alpha[i+1][alpha] = 0 
    
    return J_alpha


##############################
## n_alpha Update Functions ##   w/ different temporal discretizations
##############################
def n_alpha_update_Forward_1D(dt, Na, n_alpha_Update, n_alpha_Current, n_alpha_Past, J_alpha):
    """
    Calculates n_alpha^(k+1) from n_alpha^k using forward Euler temporal discretization
    Input: dt (float), time-step size
           Na (int), number of grid points
           n_alpha_Update (float array), (Na) x (alpha) 
           n_alpha_Current (float array), (Na) x (alpha)  
           n_alpha_Past (float array), (Na) x (alpha) 
           J_alpha (float array), (Na + 1) x (alpha) 
    Output: n_alpha_Update (float array), (Na) x (alpha) 
            n_alpha_Current (float array), (Na) x (alpha)  
            n_alpha_Past (float array), (Na) x (alpha) 
    """
    
    a = 1/Na # calculate dx
    B_x = np.arange(a/2, 1 - a/2 + 1e-15, a) # create B_x
    
    # initialize n_alpha_Update
    n_alpha_Update = np.zeros((np.shape(J_alpha)[0]-1, np.shape(J_alpha)[1]))

    J_0 = J_alpha[:len(J_alpha) - 1,:] # construct the J_0 vector
    J_1 = J_alpha[1:,:]                # construct the J_1 vector

    J_Present = J_1 - J_0 # construct the precursor to dn/dt
    
    for alpha in range(np.shape(J_alpha)[1]):
        
        n_alpha_Update[:, alpha] = n_alpha_Current[:, alpha] - (dt / a) * J_Present[:, alpha]
    
    # update the n_alpha's appropriately in preparation for the next iteration
    n_alpha_Past = n_alpha_Current
    n_alpha_Current = n_alpha_Update
    
    return n_alpha_Update, n_alpha_Current, n_alpha_Past, J_Present


def n_alpha_update_Backward_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1):

    # create copies for exploratory FE steps
    n_alpha_Update_, n_alpha_Current_, n_alpha_Past_ = n_alpha_Update, n_alpha_Current, n_alpha_Past

    a = 1/Na # calculate dx

    if (i_glob == 0): # two exploratory FE steps required to start

        n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, J_Present = iteration_Forward_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)
        n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, J_Present = iteration_Forward_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)

        # take initial BE step
        for alpha in range(np.shape(n_alpha_Update)[1]):

            n_alpha_Update[:, alpha] = n_alpha_Current[:, alpha] - (dt / a) * J_Present[:, alpha]
            # swap
            n_alpha_Past = n_alpha_Current
            n_alpha_Current = n_alpha_Update

        # take one exploratory FE step
        n_alpha_Update_, n_alpha_Current_, n_alpha_Past_ = n_alpha_Update, n_alpha_Current, n_alpha_Past # create copies
        n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, J_Present = iteration_Forward_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)

        # take 1^st BE step
        for alpha in range(np.shape(n_alpha_Update)[1]):

            n_alpha_Update[:, alpha] = n_alpha_Current[:, alpha] - (dt / a) * J_Present[:, alpha]
            # swap
            n_alpha_Past = n_alpha_Current
            n_alpha_Current = n_alpha_Update

    else: # one exploratory FE step required    

        n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, J_Present = iteration_Forward_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)
        
        # take a BE step
        for alpha in range(np.shape(n_alpha_Update)[1]):

            n_alpha_Update[:, alpha] = n_alpha_Current[:, alpha] - (dt / a) * J_Present[:, alpha]
            # swap
            n_alpha_Past = n_alpha_Current
            n_alpha_Current = n_alpha_Update

    return n_alpha_Update, n_alpha_Current, n_alpha_Past


def n_alpha_update_Theta_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, J_Past, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1, theta = 0.5):

    # create copies for exploratory FE steps
    n_alpha_Update_, n_alpha_Current_, n_alpha_Past_ = n_alpha_Update, n_alpha_Current, n_alpha_Past

    a = 1/Na # calculate dx

    if (i_glob == 0): # two exploratory FE steps required to start

        n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, J_Past = iteration_Forward_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)
        n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, J_Present = iteration_Forward_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)

        # take initial Theta step
        for alpha in range(np.shape(n_alpha_Update)[1]):

            n_alpha_Update[:, alpha] = n_alpha_Current[:, alpha] - (dt / a) * (theta * J_Present[:, alpha] + (1 - theta) * J_Past[:, alpha])
            # swap
            n_alpha_Past = n_alpha_Current
            n_alpha_Current = n_alpha_Update

        J_Past = J_Present

        # take one exploratory FE step
        n_alpha_Update_, n_alpha_Current_, n_alpha_Past_ = n_alpha_Update, n_alpha_Current, n_alpha_Past # create copies
        n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, J_Present = iteration_Forward_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)

        # take 1^st Theta step
        for alpha in range(np.shape(n_alpha_Update)[1]):

            n_alpha_Update[:, alpha] = n_alpha_Current[:, alpha] - (dt / a) * (theta * J_Present[:, alpha] + (1 - theta) * J_Past[:, alpha])
            # swap
            n_alpha_Past = n_alpha_Current
            n_alpha_Current = n_alpha_Update

        J_Past = J_Present

    else: # one exploratory FE step required    

        n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, J_Present = iteration_Forward_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)
        
        # take a Theta step
        for alpha in range(np.shape(n_alpha_Update)[1]):

            n_alpha_Update[:, alpha] = n_alpha_Current[:, alpha] - (dt / a) * (theta * J_Present[:, alpha] + (1 - theta) * J_Past[:, alpha])
            # swap
            n_alpha_Past = n_alpha_Current
            n_alpha_Current = n_alpha_Update

        J_Past = J_Present

    return n_alpha_Update, n_alpha_Current, n_alpha_Past, J_Past


def n_alpha_update_Leapfrog_1D(dt, i_glob, Na, n_alpha_Update, n_alpha_Current, n_alpha_Past, J_Present):
    
    a = 1/Na # calculate dx
    B_x = np.arange(a/2, 1 - a/2 + 1e-15, a) # create B_x
    
    # initialize n_alpha_Update
    n_alpha_Update = np.zeros((np.shape(n_alpha_Current)))

    # J_0 = J_alpha[:len(J_alpha) - 1,:] # construct the J_0 vector
    # J_1 = J_alpha[1:,:]                # construct the J_1 vector

    # J_Present = J_1 - J_0 # construct the precursor to dn/dt

    for alpha in range(np.shape(n_alpha_Current)[1]):
        
        n_alpha_Update[:, alpha] = n_alpha_Past[:, alpha] - (2 * dt / a) * J_Present[:, alpha]
    
    return n_alpha_Update, n_alpha_Current, n_alpha_Past, J_Present


#########################
## Iteration Functions ##   w/ different temporal discretizations
#########################
def iteration_Forward_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1):
# Don't know if all the input parameters are necessary...
    """
    Performs an iteration via pure forward Euler temporal discretization
    Input: dt (float), time-step size
           i_glob (int), global iteration counter (UNUSED VARIABLE)
           Na (int), number of grid points
           T (float), temperature
           k_B (float), Boltzmann's constant with appropriate units
           B_matrix (float array), 1D Poisson discretization matrix
           q_alpha (int array), each entry represents charge of a species
           n_alpha_Update (float array), (Na) x (alpha) 
           n_alpha_Current (float array), (Na) x (alpha)  
           n_alpha_Past (float array), (Na) x (alpha) 
           mu_bar_alpha (float array), (Na) x (alpha) where each column vector represents 
               mu values for one alpha 
           D_alpha (float array), (Na) x (alpha) where each column vector represents 
               D values for one alpha
           ghosts_included (bool), ...
           epsilon_0 (float), constant ...
           epsilon_r (float), constant, BUT IS IT ??????
    Output: n_alpha_Update (float array), (Na) x (alpha) 
            n_alpha_Current (float array), (Na) x (alpha)  
            n_alpha_Past (float array), (Na) x (alpha) 
    """

    # update rho
    rho = rho_update_1D(Na, n_alpha_Current, q_alpha)
    
    # update phi
    phi = phi_update_1D(Na, B_matrix, rho, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)
    
    # update mu_alpha & v_alpha, N O T E : combined mu_alpha_update_1D and v_alpha_update_1D into ONE function
    mu_alpha, v_alpha = mu_and_v_alpha_update_1D(Na, mu_bar_alpha, q_alpha, phi, D_alpha)
    
    # update J_alpha
    J_alpha = J_alpha_update_1D(Na, T, k_B, mu_alpha, v_alpha, n_alpha_Current)
    
    # update n_alpha
    n_alpha_Update, n_alpha_Current, n_alpha_Past, J_Present = n_alpha_update_Forward_1D(dt, Na, n_alpha_Update, n_alpha_Current, n_alpha_Past, J_alpha)
   
    return n_alpha_Update, n_alpha_Current, n_alpha_Past, J_Present


def iteration_Backward_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1):

    # take the BE time-step
    n_alpha_Update, n_alpha_Current, n_alpha_Past = n_alpha_update_Backward_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)

    return n_alpha_Update, n_alpha_Current, n_alpha_Past


def iteration_Theta_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, J_Past, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1):

    # take the Theta time-step
    n_alpha_Update, n_alpha_Current, n_alpha_Past, J_Past = n_alpha_update_Theta_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, J_Past, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)

    return n_alpha_Update, n_alpha_Current, n_alpha_Past, J_Past


def iteration_Leapfrog_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, J_Present, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1):
# Don't know if all the input parameters are necessary...

    # create copies for exploratory FE steps
    n_alpha_Update_, n_alpha_Current_, n_alpha_Past_ = n_alpha_Update, n_alpha_Current, n_alpha_Past

    a = 1/Na # calculate dx

    if (i_glob == 0): # two exploratory FE steps required to start
        
        # first FE step changes n_alpha values 
        n_alpha_Update, n_alpha_Current, n_alpha_Past, J_Present = iteration_Forward_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)
        
        # second FE step does NOT change n_alpha values ==> copies used 
        n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, J_Present = iteration_Forward_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update_, n_alpha_Current_, n_alpha_Past_, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)

        # Note : at the end of the 1st time-step, we use the 2nd exploratory FE step's output J_Present in preparation for the 1st Leapfrog step

    else: # Leapfrog updates
        
        # update n_alpha
        n_alpha_Update, n_alpha_Current, n_alpha_Past, J_Present = n_alpha_update_Leapfrog_1D(dt, i_glob, Na, n_alpha_Update, n_alpha_Current, n_alpha_Past, J_Present)

        # print(np.transpose(n_alpha_Past))
        # print(np.transpose(n_alpha_Current))
        # print(np.transpose(n_alpha_Update))
        # print('\n')

        n_alpha_Past[n_alpha_Past<0] = 0
        n_alpha_Current[n_alpha_Current<0] = 0
        n_alpha_Update[n_alpha_Update<0] = 0



        # update rho
        rho = rho_update_1D(Na, n_alpha_Update, q_alpha)
    
        # update phi
        phi = phi_update_1D(Na, B_matrix, rho, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)
    
        # update mu_alpha & v_alpha, N O T E : combined mu_alpha_update_1D and v_alpha_update_1D into ONE function
        mu_alpha, v_alpha = mu_and_v_alpha_update_1D(Na, mu_bar_alpha, q_alpha, phi, D_alpha)
    
        # update J_alpha
        J_alpha = J_alpha_update_1D(Na, T, k_B, mu_alpha, v_alpha, n_alpha_Update)
    
        # calculate J_Present
        J_0 = J_alpha[:len(J_alpha) - 1,:] # construct the J_0 vector
        J_1 = J_alpha[1:,:]                # construct the J_1 vector

        J_Present = J_1 - J_0 # construct the precursor to dn/dt

        # swap n_alpha
        n_alpha_Past = n_alpha_Current
        n_alpha_Current = n_alpha_Update

    return n_alpha_Update, n_alpha_Current, n_alpha_Past, J_Present


##########################
## Simulation Functions ##   w/ different temporal discretizations
##########################
def simulation_Forward_1D(dt, tmax, Na, T, k_B, n_alpha_Update, n_alpha_Current, n_alpha_Past, q_alpha, mu_bar_alpha, D_alpha, plotting = False): # dt, Na, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1
    
    i_glob = 0 # global iteration counter (specifically for 1st timestep's n'(x, t) calculation)
    t_cur = 0.0  # global time counter
    
    a = 1/Na # calculate dx
    
    A_x = np.arange(0, 1 + 1e-15, a)         # length of Na + 1
    B_x = np.arange(a/2, 1 - a/2 + 1e-15, a) # length of Na
    
    # initialize 
    n_alpha_Update = np.zeros((len(B_x), 1))
    n_plotting = np.array([])
    
    # construct the Poisson 1D discretization matrix B
    B_matrix = B_construct_1D(Na, ghosts_included = True)
    
    # start plotting/animating
    fig = plt.figure() # initialize figure
    axis = plt.axes(xlim =(0, 1), ylim =(-2, 10)) # marking the x-axis and y-axis 
    line, = axis.plot([], [], lw = 3) # initializing a line variable 
    plt.close() # to not have a stray plot
    
    # data which the line will 
    # contain (x, y) 
    def init(): 
        line.set_data([], []) 
        return line, 
    
    def animate(i): 
        x = np.arange(a/2, 1 - a/2 + 1e-15, a) # set the x axis to B_x

        if (i < int(tmax/dt - 1e-15)):
            
            n_plot = n_plot_matrix[i,:] # extract the i^th row for plotting
        
            line.set_data(x, n_plot) 
            
        else:
            
            return line,
      
        return line,
    
    
    while (t_cur < tmax):
        
        n_alpha_Update, n_alpha_Current, n_alpha_Past, J_Present = iteration_Forward_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)
        
        if (plotting):
            
            n_plotting = np.append(n_plotting, n_alpha_Update)
                     
        i_glob += 1
        t_cur += dt
        
    if (plotting):
        
        n_plot_matrix = n_plotting.reshape((int(tmax/dt - 1e-15) + 1, len(B_x))) # every row corresponds to N_alpha 
                                                                 # at a different time-step  
        anim = FuncAnimation(fig, animate, init_func = init, frames = 500, interval = 20, blit = True)
        
        #return HTML(anim.to_jshtml())
        
        return anim
    
    else:
        
        print('\nSimulation completed at time', t_cur, '!!!')
        
        return n_alpha_Current, t_cur


def simulation_Backward_1D(dt, tmax, Na, T, k_B, n_alpha_Update, n_alpha_Current, n_alpha_Past, q_alpha, mu_bar_alpha, D_alpha, plotting = False): # dt, Na, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1
    
    i_glob = 0 # global iteration counter (specifically for 1st timestep's n'(x, t) calculation)
    t_cur = 0.0  # global time counter
    
    a = 1/Na # calculate dx
    
    A_x = np.arange(0, 1 + 1e-15, a)         # length of Na + 1
    B_x = np.arange(a/2, 1 - a/2 + 1e-15, a) # length of Na
    
    # initialize 
    n_alpha_Update = np.zeros((len(B_x), 1))
    n_plotting = np.array([])
    
    # construct the Poisson 1D discretization matrix B
    B_matrix = B_construct_1D(Na, ghosts_included = True)
    
    # start plotting/animating
    fig = plt.figure() # initialize figure
    axis = plt.axes(xlim =(0, 1), ylim =(-2, 10)) # marking the x-axis and y-axis 
    line, = axis.plot([], [], lw = 3) # initializing a line variable 
    plt.close() # to not have a stray plot
    
    # data which the line will 
    # contain (x, y) 
    def init(): 
        line.set_data([], []) 
        return line, 
    
    def animate(i): 
        x = np.arange(a/2, 1 - a/2 + 1e-15, a) # set the x axis to B_x

        if (i < int(tmax/dt - 1e-15)):
            
            n_plot = n_plot_matrix[i,:] # extract the i^th row for plotting
        
            line.set_data(x, n_plot) 
            
        else:
            
            return line,
      
        return line,
    
    
    while (t_cur < tmax):
        
        n_alpha_Update, n_alpha_Current, n_alpha_Past = iteration_Backward_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)
        
        if (plotting):
            
            n_plotting = np.append(n_plotting, n_alpha_Update)
                     
        i_glob += 1
        t_cur += dt
        
    if (plotting):
        
        n_plot_matrix = n_plotting.reshape((int(tmax/dt - 1e-15) + 1, len(B_x))) # every row corresponds to N_alpha 
                                                                 # at a different time-step  
        anim = FuncAnimation(fig, animate, init_func = init, frames = 500, interval = 20, blit = True)
        
        #return HTML(anim.to_jshtml())
        
        return anim
    
    else:
        
        print('\nSimulation completed at time', t_cur, '!!!')
        
        return n_alpha_Current, t_cur


def simulation_Theta_1D(dt, tmax, Na, T, k_B, n_alpha_Update, n_alpha_Current, n_alpha_Past, q_alpha, mu_bar_alpha, D_alpha, plotting = False): # dt, Na, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1
    
    i_glob = 0 # global iteration counter (specifically for 1st timestep's n'(x, t) calculation)
    t_cur = 0.0  # global time counter
    
    a = 1/Na # calculate dx
    
    A_x = np.arange(0, 1 + 1e-15, a)         # length of Na + 1
    B_x = np.arange(a/2, 1 - a/2 + 1e-15, a) # length of Na
    
    # initialize 
    n_alpha_Update = np.zeros(np.shape(n_alpha_Update))
    n_plotting = np.array([])
    
    # construct the Poisson 1D discretization matrix B
    B_matrix = B_construct_1D(Na, ghosts_included = True)

    # initialize J_Past = 0
    J_Past = np.zeros(np.shape(n_alpha_Update))
    
    # start plotting/animating
    fig = plt.figure() # initialize figure
    axis = plt.axes(xlim =(0, 1), ylim =(-2, 10)) # marking the x-axis and y-axis 
    line, = axis.plot([], [], lw = 3) # initializing a line variable 
    plt.close() # to not have a stray plot
    
    # data which the line will 
    # contain (x, y) 
    def init(): 
        line.set_data([], []) 
        return line, 
    
    def animate(i): 
        x = np.arange(a/2, 1 - a/2 + 1e-15, a) # set the x axis to B_x

        if (i < int(tmax/dt - 1e-15)):
            
            n_plot = n_plot_matrix[i,:] # extract the i^th row for plotting
        
            line.set_data(x, n_plot) 
            
        else:
            
            return line,
      
        return line,
    
    
    while (t_cur < tmax):
        
        n_alpha_Update, n_alpha_Current, n_alpha_Past, J_Past = iteration_Theta_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, J_Past, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)
        
        if (plotting):
            
            n_plotting = np.append(n_plotting, n_alpha_Update)
                     
        i_glob += 1
        t_cur += dt
        
    if (plotting):
        
        n_plot_matrix = n_plotting.reshape((int(tmax/dt - 1e-15) + 1, len(B_x))) # every row corresponds to N_alpha 
                                                                 # at a different time-step  
        anim = FuncAnimation(fig, animate, init_func = init, frames = 500, interval = 20, blit = True)
        
        #return HTML(anim.to_jshtml())
        
        return anim
    
    else:
        
        print('\nSimulation completed at time', t_cur, '!!!')
        
        return n_alpha_Current, t_cur

  
def simulation_Leapfrog_1D(dt, tmax, Na, T, k_B, n_alpha_Update, n_alpha_Current, n_alpha_Past, q_alpha, mu_bar_alpha, D_alpha, plotting = False): # dt, Na, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1
    
    i_glob = 0 # global iteration counter (specifically for 1st timestep's n'(x, t) calculation)
    t_cur = 0.0  # global time counter
    
    a = 1/Na # calculate dx
    
    A_x = np.arange(0, 1 + 1e-15, a)         # length of Na + 1
    B_x = np.arange(a/2, 1 - a/2 + 1e-15, a) # length of Na
    
    # initialize 
    n_alpha_Update = np.zeros((len(B_x), 1))
    n_plotting = np.array([])

    # initialize
    J_Present = np.zeros(np.shape(n_alpha_Update))
    
    # construct the Poisson 1D discretization matrix B
    B_matrix = B_construct_1D(Na, ghosts_included = True)
    
    # start plotting/animating
    fig = plt.figure() # initialize figure
    axis = plt.axes(xlim =(0, 1), ylim =(-2, 10)) # marking the x-axis and y-axis 
    line, = axis.plot([], [], lw = 3) # initializing a line variable 
    plt.close() # to not have a stray plot
    
    # data which the line will 
    # contain (x, y) 
    def init(): 
        line.set_data([], []) 
        return line, 
    
    def animate(i): 
        x = np.arange(a/2, 1 - a/2 + 1e-15, a) # set the x axis to B_x

        if (i < int(tmax/dt - 1e-15)):
            
            n_plot = n_plot_matrix[i,:] # extract the i^th row for plotting
        
            line.set_data(x, n_plot) 
            
        else:
            
            return line,
      
        return line,
    
    
    while (t_cur < tmax):
        
        n_alpha_Update, n_alpha_Current, n_alpha_Past, J_Present = iteration_Leapfrog_1D(dt, i_glob, Na, T, k_B, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, J_Present, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)
        
        if (plotting):
            
            n_plotting = np.append(n_plotting, n_alpha_Update)
                     
        i_glob += 1
        t_cur += dt
        
    if (plotting):
        
        n_plot_matrix = n_plotting.reshape((int(tmax/dt - 1e-15) + 1, len(B_x))) # every row corresponds to N_alpha 
                                                                 # at a different time-step  
        anim = FuncAnimation(fig, animate, init_func = init, frames = 500, interval = 20, blit = True)
        
        #return HTML(anim.to_jshtml())
        
        return anim
    
    else:
        
        print('\nSimulation completed at time', t_cur, '!!!')
        
        return n_alpha_Current, t_cur
 

