print("You have selected the 2D CPFM simulation.")

from IPython import display
import numpy as np
import scipy.sparse
import matplotlib.pyplot as plt
from matplotlib import cm
import scipy.sparse.linalg
import math

def B_construct_1D(Na, ghosts_included = True):
    """
    Input: Na (int), number of grid points
           ghosts_included (bool), default is True (B is (Na-2) x (Na-2) and rho is Na-2)
                                           if False (B is (Na) x (Na) and rho is Na)
    Output: B (float array), 1D Poisson discretization matrix
    """
    # construct the tridiagonal Poisson discretization matrix B
    if (ghosts_included):
        
        offsets = [-1, 0, 1] 
        diags = []
        diags.append(-np.ones(Na-3)) 
        diags.append(2 * np.ones(Na-2))
        diags.append(-np.ones(Na-3))
        B = scipy.sparse.diags(diags, offsets, format='csr') # construct a CSR version of B
        B = B.toarray() # this function will only be called once so CSR not too important
        #print('The shape of B is', np.shape(B))
        #print('\nB is \n', B)        
    else:    
        offsets = [-1, 0, 1] 
        diags = []
        
        diags.append(-np.ones(Na-3)) 
        diags.append(2 * np.ones(Na-2))
        diags.append(-np.ones(Na-3))
        B = scipy.sparse.diags(diags, offsets, format='csr') # construct a CSR version of B
        B = B.toarray() # this function will only be called once so CSR not too important
        B = np.pad(B, [1, 1], mode='constant')
        B[0][0] = 1
        B[np.shape(B)[0]-1][np.shape(B)[0]-1] = 1
        #print('The shape of B is', np.shape(B))
        #print('\nB is \n', B)

    return B


def poisson_matrix_2D(Na, ghosts_included = True):
    
    B = B_construct_1D(Na, ghosts_included)
    
    if (ghosts_included):
        
        # construct the Poisson discretization matrix A
        A = np.kron(B, np.eye(np.shape(B)[0])) + np.kron(np.eye(np.shape(B)[0]), B)
        
    else:
        
        print('Error: Not Implemented yet :) OOPS')
    
    print('The shape of B is', np.shape(B))
    print('The shape of A is', np.shape(A))
    
    return A


def rho_update_2D(Na, n_alpha, q_alpha):
    
    rho = np.zeros(np.shape(n_alpha)[1:]) # set rho to Na x Na size, bypass the 1st array dimension
    
    # iterate over the alphas
    for i in range(np.shape(n_alpha)[0]):
        
        rho += n_alpha[i] * q_alpha[i]
        
    return rho # return 2D rho array
        

def phi_update_2D(Na, A_matrix, rho, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1): 
    
    a = 1.0/Na # calculate dx
    
    c_rho = a**2 * np.exp(1)**2 / (2.0 * epsilon_0 * epsilon_r) # IS THIS STILL THE SAME AS IT WAS IN 1D ?????
    
    if (ghosts_included):
        
        rho_vec = rho[1:-1,1:-1] # remove boundaries/ghosts
        rho_vec = rho_vec.flatten() # from 2D to 1D
        
        phi_soln = scipy.sparse.linalg.cg(A_matrix, c_rho * rho_vec)[0]
        phi_soln = phi_soln.reshape((Na - 2, Na - 2))
        phi = np.pad(phi_soln,1)
    
    else:
        
        print('Error: Not Implemented yet :) OOPS')
        
    return phi # phi is returned as a 2D array here


def mu_and_v_alpha_update_2D(Na, T, k_B, mu_bar_alpha, q_alpha, phi, D_alpha):
    
    #Phi = phi.reshape((int(Na), int(Na))) # store Phi as a 2D Na x Na array
    
    a = 1.0/Na # dx
    
    # initialize mu_alpha
    mu_alpha = np.zeros(np.shape(mu_bar_alpha))

    # initialize v_alpha
    v_alpha = np.zeros(np.shape(mu_bar_alpha))
    
    for i in range(len(q_alpha)): # loop over 1st dimension (layer) of 3D mu_alpha & v_alpha tensors
        
        mu_alpha[i] = mu_bar_alpha[i] + q_alpha[i] * phi  

        v_alpha[i] = (1.0/a) * D_alpha[i]
        
    # now store mu_alpha as an exponential array 
    
    c = 2 * k_B * T # just store as one value
    
    mu_alpha = np.exp(mu_alpha/c)
          
    return mu_alpha, v_alpha # both returned as 3D alpha x Na x Na arrays


def J_alpha_update_2D(Na, T, k_B, mu_alpha, v_alpha, n_alpha):
    """
    Input: Na (int), number of grid points
           T (float), temperature
           mu_alpha (float array), (Na) x (alpha) 
           v_alpha (float array), (Na) x (alpha) 
           n_alpha (float array), (Na) x (alpha) 
    Output: J_alpha (float array), (Na + 1) x (alpha) particle current array
    """
    
    # initialize J_alpha_UMat to have m x (Na) x (Na) dimensions
    J_alpha_UMat = np.zeros((np.shape(n_alpha)[0], np.shape(n_alpha)[1], np.shape(n_alpha)[2]))
    # Our update matrix which we will simply scale and then add on n_alpha_Current !!! Pretty COOL !
    
    # Our axes : +-----> (x-axis)
    #            |
    #            |
    #            v (y-axis)
    # each cell n_alpha has 4 possible neighbors, left, right, top, bottom
        # all of these neighbors exchange information to form dn/dt
        # NOTE: some cells have 2 (corner) or 3 (edge) neighbors which needs to be accounted for
    
    # now iterate over each grid index, update J_alpha_UMat values for all alphas each iteration
    
    # 1st : Deal with the Interior (Na - 2) x (Na - 2) domain
    for i in range(1, np.shape(n_alpha)[1] - 1):
        for j in range(1, np.shape(n_alpha)[2] - 1):
            
            # signs given to be positive if flow into cell i,j
            J_left = v_alpha[:,i-1,j] * n_alpha[:,i-1,j] * mu_alpha[:,i-1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i-1,j]
            J_right = v_alpha[:,i+1,j] * n_alpha[:,i+1,j] * mu_alpha[:,i+1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i+1,j]
            J_top = v_alpha[:,i,j-1] * n_alpha[:,i,j-1] * mu_alpha[:,i,j-1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j-1]
            J_bottom = v_alpha[:,i,j+1] * n_alpha[:,i,j+1] * mu_alpha[:,i,j+1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j+1]
            
            J_alpha_UMat[:,i,j] = J_left + J_right + J_top + J_bottom
            
    
    # 2nd : Deal with the Edges
    for j in range(1, np.shape(n_alpha)[2] - 1):
        
        # left column
        i = 0
        J_right = v_alpha[:,i+1,j] * n_alpha[:,i+1,j] * mu_alpha[:,i+1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i+1,j]
        J_top = v_alpha[:,i,j-1] * n_alpha[:,i,j-1] * mu_alpha[:,i,j-1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j-1]
        J_bottom = v_alpha[:,i,j+1] * n_alpha[:,i,j+1] * mu_alpha[:,i,j+1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j+1]
        J_alpha_UMat[:,i,j] = J_top + J_bottom + J_right # left column 
    
        # right column
        i = np.shape(n_alpha)[1] - 1
        J_left = v_alpha[:,i-1,j] * n_alpha[:,i-1,j] * mu_alpha[:,i-1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i-1,j]
        J_top = v_alpha[:,i,j-1] * n_alpha[:,i,j-1] * mu_alpha[:,i,j-1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j-1]
        J_bottom = v_alpha[:,i,j+1] * n_alpha[:,i,j+1] * mu_alpha[:,i,j+1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j+1]
        J_alpha_UMat[:,i,j] = J_top + J_bottom + J_left # right column 
    
    for i in range(1, np.shape(n_alpha)[1] - 1):
    
        # top row
        j = 0
        J_left = v_alpha[:,i-1,j] * n_alpha[:,i-1,j] * mu_alpha[:,i-1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i-1,j]
        J_right = v_alpha[:,i+1,j] * n_alpha[:,i+1,j] * mu_alpha[:,i+1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i+1,j]
        J_bottom = v_alpha[:,i,j+1] * n_alpha[:,i,j+1] * mu_alpha[:,i,j+1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j+1]
        J_alpha_UMat[:,i,j] = J_left + J_right + J_bottom
       
        # bottom row
        j = np.shape(n_alpha)[2] - 1
        J_left = v_alpha[:,i-1,j] * n_alpha[:,i-1,j] * mu_alpha[:,i-1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i-1,j]
        J_right = v_alpha[:,i+1,j] * n_alpha[:,i+1,j] * mu_alpha[:,i+1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i+1,j]
        J_top = v_alpha[:,i,j-1] * n_alpha[:,i,j-1] * mu_alpha[:,i,j-1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j-1]
        J_alpha_UMat[:,i,j] = J_left + J_right + J_top   
    
    # 3rd : Deal with the Corners
    
    # top left corner
    i = 0
    j = 0
    J_right = v_alpha[:,i+1,j] * n_alpha[:,i+1,j] * mu_alpha[:,i+1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i+1,j]
    J_bottom = v_alpha[:,i,j+1] * n_alpha[:,i,j+1] * mu_alpha[:,i,j+1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j+1]
    J_alpha_UMat[:,i,j] = J_bottom + J_right 
    
    # top right corner
    i = np.shape(n_alpha)[1] - 1
    j = 0
    J_left = v_alpha[:,i-1,j] * n_alpha[:,i-1,j] * mu_alpha[:,i-1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i-1,j]
    J_bottom = v_alpha[:,i,j+1] * n_alpha[:,i,j+1] * mu_alpha[:,i,j+1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j+1]
    J_alpha_UMat[:,i,j] = J_bottom + J_left
    
    # bottom left corner
    i = 0
    j = np.shape(n_alpha)[2] - 1
    J_right = v_alpha[:,i+1,j] * n_alpha[:,i+1,j] * mu_alpha[:,i+1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i+1,j]
    J_top = v_alpha[:,i,j-1] * n_alpha[:,i,j-1] * mu_alpha[:,i,j-1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j-1] 
    J_alpha_UMat[:,i,j] = J_top + J_right
    
    # bottom right corner
    i = np.shape(n_alpha)[1] - 1
    j = np.shape(n_alpha)[2] - 1
    J_left = v_alpha[:,i-1,j] * n_alpha[:,i-1,j] * mu_alpha[:,i-1,j] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i-1,j]
    J_top = v_alpha[:,i,j-1] * n_alpha[:,i,j-1] * mu_alpha[:,i,j-1] / mu_alpha[:,i,j] - v_alpha[:,i,j] * n_alpha[:,i,j] * mu_alpha[:,i,j] / mu_alpha[:,i,j-1]
   
    return J_alpha_UMat


def n_alpha_update_Forward_2D(dt, Na, n_alpha_Update, n_alpha_Current, n_alpha_Past, J_alpha_UMat):
    
    a = 1/Na # calculate dx
    B_x = np.arange(a/2, 1 - a/2 + 1e-15, a) # create B_x
    
    # initialize n_alpha_Update
    n_alpha_Update = np.zeros(np.shape(n_alpha_Past))

    # NOTE : The 1D J_Present method NOT implemented
                                    # needs to be dt * a
    n_alpha_Update = n_alpha_Current + (dt / a) * J_alpha_UMat
    
    # update the n_alpha's appropriately in preparation for the next iteration
    n_alpha_Past = n_alpha_Current
    n_alpha_Current = n_alpha_Update
    
    return n_alpha_Update, n_alpha_Current, n_alpha_Past


def iteration_Forward_2D(dt, i_glob, Na, T, k_B, A_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1):
    
    # update rho
    rho = rho_update_2D(Na, n_alpha_Current, q_alpha)
    
    # update phi
    phi = phi_update_2D(Na, A_matrix, rho, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)
    
    # update mu_alpha & v_alpha, N O T E : combined mu_alpha_update_1D and v_alpha_update_1D into ONE function
    mu_alpha, v_alpha = mu_and_v_alpha_update_2D(Na, T, k_B, mu_bar_alpha, q_alpha, phi, D_alpha)
    
    # update J_alpha
    J_alpha_UMat = J_alpha_update_2D(Na, mu_alpha, v_alpha, n_alpha_Current)
    
    # update n_alpha
    n_alpha_Update, n_alpha_Current, n_alpha_Past = n_alpha_update_Forward_2D(dt, Na, n_alpha_Update, n_alpha_Current, n_alpha_Past, J_alpha_UMat)
   
    return n_alpha_Update, n_alpha_Current, n_alpha_Past


def simulation_Forward_2D(dt, tmax, Na, T, k_B, n_alpha_Update, n_alpha_Current, n_alpha_Past, q_alpha, mu_bar_alpha, D_alpha, plotting = False): # dt, Na, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1
    
    i_glob = 0 # global iteration counter (specifically for 1st timestep's n'(x, t) calculation)
    t_cur = 0.0  # global time counter
    
    a = 1/Na # calculate dx
    
    A_x = np.arange(0, 1 + 1e-15, a)         # length of Na + 1
    B_x = np.arange(a/2, 1 - a/2 + 1e-15, a) # length of Na
    
    # initialize 
    n_alpha_Update = np.zeros((len(B_x), 1))
    n_plotting = np.array([])
    
    # construct the Poisson 1D discretization matrix B
    A_matrix = poisson_matrix_2D(Na, ghosts_included = True)
    
    # start plotting/animating
    fig = plt.figure() # initialize figure
    axis = plt.axes(xlim =(0, 1), ylim =(-2, 10)) # marking the x-axis and y-axis 
    line, = axis.plot([], [], lw = 3) # initializing a line variable 
    plt.close() # to not have a stray plot
    
    # data which the line will 
    # contain (x, y) 
    def init(): 
        line.set_data([], []) 
        return line, 
    
    def animate(i): 
        x = np.arange(a/2, 1 - a/2 + 1e-15, a) # set the x axis to B_x

        if (i < int(tmax/dt - 1e-15)):
            
            n_plot = n_plot_matrix[i,:] # extract the i^th row for plotting
        
            line.set_data(x, n_plot) 
            
        else:
            
            return line,
      
        return line,
    
    
    while (t_cur < tmax):
        
        n_alpha_Update, n_alpha_Current, n_alpha_Past = iteration_Forward_2D(dt, i_glob, Na, T, k_B, A_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)
        
        if (plotting):
            
            n_plotting = np.append(n_plotting, n_alpha_Update)
                     
        i_glob += 1
        t_cur += dt
        
    if (plotting):
        
        n_plot_matrix = n_plotting.reshape((int(tmax/dt - 1e-15) + 1, len(B_x))) # every row corresponds to N_alpha 
                                                                 # at a different time-step  
        anim = FuncAnimation(fig, animate, init_func = init, frames = 500, interval = 20, blit = True)
        
        #return HTML(anim.to_jshtml())
        
        return anim
    
    else:
        
        print('\nSimulation completed at time', t_cur, '!!!')
        
        return n_alpha_Current, t_cur





