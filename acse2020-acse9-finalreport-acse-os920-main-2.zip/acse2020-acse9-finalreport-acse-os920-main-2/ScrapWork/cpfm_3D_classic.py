print("You have selected the 3D CPFM simulation.")

from IPython import display
import numpy as np
import scipy.sparse
import matplotlib.pyplot as plt
from matplotlib import cm
import scipy.sparse.linalg
import math

# Note : np.kron() takes a very long time, especially in 3D where a cubic domain 
# results in an Na^3 x Na^3 Poisoon discretization matrix. This implementation is 
# stable for square-prism domains (Nx = Nz > 3, Ny > 3). Slight phase-instabilities
# may arise when Nx != Nz 
#If the domain is cubic, Nx = Ny = Nz = Na
def poisson_matrix_3D(Nx, Ny, Nz):
    """
    Input: Nx, Ny, Nz (int), number of grid points in each respective direction
    Output: A (float array), 3D Poisson discretization matrix
    """
    
    # initialize the 3D Poisson discretization matrix
    A_matrix = np.zeros((Nx*Ny*Nz, Nx*Ny*Nz))
    
    # add the diagonal entries corresponding to the top and bottom neighbors (of the cells on the main diagonal) respectively
    A_matrix += np.diag(np.ones(Nx * Ny * Nz - Nx), -Nx) + np.diag(np.ones(Nx * Ny * Nz - Nx), Nx) 
    
    # Below, essentially iterate over main diagonal rather than  all entries (cuts computational cost by ~ a square root)
    for i in range(Nx*Ny*Nz): 
        
        # add the main diagonal entries corresponding to the "current" cells
            # all other entries on the same row represent these cells' respective neighborhoods
        A_matrix[i][i] = -6
        
        # add the diagonal entries corresponding to the right neighbors 
        if (i > 0):
            A_matrix[i-1][i] = 1

        # checks if "current" cell is at the end of a row
        if (((i + 1) % Nx == 1) and (i < Nx * Ny * Nz - 1)): 
            
            # "current" cell does NOT have a right neighbor
            A_matrix[i-1][i] = 0

        # add the diagonal entries corresponding to the left neighbors    
        if (i > 0):
            
            A_matrix[i][i-1] = 1

        # checks if "current" cell is at the beginning of a row    
        if (((i + 1) % Nx == 1) and (i > 2)):
            
            # "current" cell does NOT have a left neighbor
            A_matrix[i][i-1] = 0
            
        # checks if "current" cell is at the beginning of a z-layer (depth) 
        if (((i + 1) % (Nx*Ny) == 0) and (i < Nx * Ny * Nz - Nx)):
            
            # reset i (to remove non-existent top and bottom neighbors, all assumed to exist at the beginning)
            i -= Nx-1

            # will use to remove Nx top and Nx bottom neighbors            
            cntr = 0
            
            while (cntr < Nx):
                
                A_matrix[i+cntr+Nx][i+cntr] = 0 # "current" cell does NOT have a top neighbor
                A_matrix[i+cntr][i+cntr+Nx] = 0 # "current" cell does NOT have a bottom neighbor
                
                cntr += 1
            
            # set i back to pre-while loop value
            i += Nx-1

    # add the diagonal entries corresponding to the front and back neighbors (of the cells on the main diagonal) respectively       
    A_matrix += np.diag(np.ones(Nx * Ny * Nz - Nx * Ny), -Nx*Ny) + np.diag(np.ones(Nx * Ny * Nz - Nx * Ny), Nx*Ny)
    
    return -A_matrix


def rho_update_3D(Na, n_alpha, q_alpha):
    
    rho = np.zeros(np.shape(n_alpha)[1:]) # set rho to Na x Na size, bypass the 1st array dimension
    
    # iterate over the alphas
    for i in range(np.shape(n_alpha)[0]):
        
        rho += n_alpha[i] * q_alpha[i]
        
    return rho # return 3D rho array
        

def phi_update_3D(Na, A_matrix, rho, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1): 
    
    a = 1.0/Na # calculate dx
    
    c_rho = a**2 * np.exp(1)**2 / (2.0 * epsilon_0 * epsilon_r) # IS THIS STILL THE SAME AS IT WAS IN 1D and 2D ?????
    
    if (ghosts_included):
        
        rho_vec = rho[1:-1,1:-1,1:-1] # remove boundaries/ghosts
        rho_vec = rho_vec.flatten() # from 3D to 1D
        
        phi_soln = scipy.sparse.linalg.cg(A_matrix, c_rho * rho_vec)[0]
        phi_soln = phi_soln.reshape((Na - 2, Na - 2, Na - 2))
        phi = np.pad(phi_soln,1)
    
    else:
        
        print('Error: Not Implemented yet :) OOPS')
        
    return phi # phi is returned as a 3D array here


def mu_and_v_alpha_update_3D(Na, T, k_B, mu_bar_alpha, q_alpha, phi, D_alpha):
    
    #Phi = phi.reshape((int(Na), int(Na))) # store Phi as a 2D Na x Na array
    
    a = 1.0/Na # dx
    
    # initialize mu_alpha
    mu_alpha = np.zeros(np.shape(mu_bar_alpha))

    # initialize v_alpha
    v_alpha = np.zeros(np.shape(mu_bar_alpha))

    c = 2 * k_B * T # just store as a constant
    
    for i in range(len(q_alpha)): # loop over 1st dimension (layer) of 3D mu_alpha & v_alpha tensors
                                        # might reconsider q_alpha[i] * phi
        mu_alpha[i] = mu_bar_alpha[i] + q_alpha[i] * phi  

        v_alpha[i] = (1.0/a) * D_alpha[i]

    mu_alpha = np.exp(mu_alpha/c) # "exponentialize" mu_alpha to cut down computational 
                                  #cost for the J_alpha_update_3D function
          
    return mu_alpha, v_alpha # both returned as 4D alpha x Na x Na x Na arrays


def J_alpha_update_3D(Na, T, k_B, mu_alpha, v_alpha, n_alpha):
    """
    Input: Na (int), number of grid points
           T (float), temperature
           mu_alpha (float array), (Na) x (alpha) 
           v_alpha (float array), (Na) x (alpha) 
           n_alpha (float array), (Na) x (alpha) 
    Output: J_alpha (float array), (Na + 1) x (alpha) particle current array
    """
    
    # initialize J_alpha_UMat to have m x (Na) x (Na) x (Na) dimensions
    J_alpha_UMat = np.zeros((np.shape(n_alpha)[0], np.shape(n_alpha)[1], np.shape(n_alpha)[2], np.shape(n_alpha)[3]))
    # Our update matrix which we will simply scale and then add on n_alpha_Current !!! Pretty COOL !
    
    # Our axes : +-----> (x-axis)
    #           /|
    #          / |
    #(z-axis) v  v (y-axis)
    # each cell n_alpha has 6 possible neighbors, left, right, top, bottom, front, back
        # all of these neighbors exchange information to form dn/dt
        # NOTE: some cells have 3 (corner) or 4 (edge) or 5 (surface) neighbors which needs to be accounted for
                #(any rectangular prism domain has 8 corner cells, 12 * (Na - 2) edge cells, 
                # and 6 * (Na - 2)^2 surface cells)
    # now iterate over each grid index, update J_alpha_UMat values for all alphas each iteration
    
    c = np.exp(-1) # just store as one value
    
    # 1st : Deal with the Interior (Na - 2) x (Na - 2) x (Na - 2) domain
    for i in range(1, np.shape(n_alpha)[1] - 1):
        for j in range(1, np.shape(n_alpha)[2] - 1):
            for k in range(1, np.shape(n_alpha)[3] - 1):
            
                # signs given to be positive if flow into cell i,j
                J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
                J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
                J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
                J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
                J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]
                J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]
            
                J_alpha_UMat[:,i,j,k] = J_left + J_right + J_top + J_bottom + J_front + J_back
    
    
    # 2nd : Deal with the Surfaces
    for i in range(1, np.shape(n_alpha)[1] - 1):
        for j in range(1, np.shape(n_alpha)[2] - 1):
            
            # top surface
            k = 0
            J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
            J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
            J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
            J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
            J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]
            
            J_alpha_UMat[:,i,j,k] = J_left + J_right + J_top + J_bottom + J_back
    
            # bottom surface
            k = np.shape(n_alpha)[3] - 1
            J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
            J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
            J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
            J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
            J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]
            
            J_alpha_UMat[:,i,j,k] = J_left + J_right + J_top + J_bottom + J_front 
    
    for i in range(1, np.shape(n_alpha)[1] - 1):
        for k in range(1, np.shape(n_alpha)[3] - 1):
            
            # front surface
            j = 0
            J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
            J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
            J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
            J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]
            J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]
            
            J_alpha_UMat[:,i,j,k] = J_left + J_right + J_bottom + J_front + J_back
    
            # bottom surface
            j = np.shape(n_alpha)[2] - 1
            J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
            J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
            J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
            J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]
            J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]
            
            J_alpha_UMat[:,i,j,k] = J_left + J_right + J_top + J_front + J_back
    
    for j in range(1, np.shape(n_alpha)[2] - 1):
        for k in range(1, np.shape(n_alpha)[3] - 1):
            
            # left surface
            i = 0
            J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
            J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
            J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
            J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]
            J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]
            
            J_alpha_UMat[:,i,j,k] = J_right + J_top + J_bottom + J_front + J_back
    
            # right surface
            i = np.shape(n_alpha)[1] - 1
            J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
            J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
            J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
            J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]
            J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]
            
            J_alpha_UMat[:,i,j,k] = J_left + J_top + J_bottom + J_front + J_back
    
    
    # 3rd : Deal with the Edges
        # NOTE : each edge corresponds to fixing two of the i,j,k indices and varying the other
        # varing i,j,k respectively should yield 4 edges per index, so 3*4 = 12
    for i in range(1, np.shape(n_alpha)[1] - 1):
        
        # bottom back 
        j = 0
        k = 0
        J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
        J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
        J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
        J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]
            
        J_alpha_UMat[:,i,j,k] = J_left + J_right + J_bottom + J_back
    
        # bottom front
        j = np.shape(n_alpha)[2] - 1
        k = 0
        J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
        J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
        J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
        J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]
            
        J_alpha_UMat[:,i,j,k] = J_left + J_right + J_top + J_back
        
        # top back
        j = 0
        k = np.shape(n_alpha)[3] - 1
        J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
        J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
        J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
        J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]
        
        J_alpha_UMat[:,i,j,k] = J_left + J_right + J_bottom + J_front
        
        # top front
        j = np.shape(n_alpha)[2] - 1
        k = np.shape(n_alpha)[3] - 1
        J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
        J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
        J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
        J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]
            
        J_alpha_UMat[:,i,j,k] = J_left + J_right + J_top + J_front
        
    for j in range(1, np.shape(n_alpha)[2] - 1):
        
        # left bottom
        i = 0
        k = 0
        J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
        J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
        J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
        J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]
            
        J_alpha_UMat[:,i,j,k] = J_right + J_top + J_bottom + J_back
        
        # right bottom
        i = np.shape(n_alpha)[1] - 1
        k = 0
        J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
        J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
        J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
        J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]
            
        J_alpha_UMat[:,i,j,k] = J_left + J_top + J_bottom + J_back
        
        # left top
        i = 0
        k = np.shape(n_alpha)[3] - 1
        J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
        J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
        J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
        J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]
            
        J_alpha_UMat[:,i,j,k] = J_right + J_top + J_bottom + J_front
        
        # right top
        i = np.shape(n_alpha)[1] - 1
        k = np.shape(n_alpha)[3] - 1
        J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
        J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
        J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
        J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]
            
        J_alpha_UMat[:,i,j,k] = J_left + J_top + J_bottom + J_front
        
    for k in range(1, np.shape(n_alpha)[3] - 1):
        
        # left back
        i = 0
        j = 0
        J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
        J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
        J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]
        J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]
            
        J_alpha_UMat[:,i,j,k] = J_right + J_bottom + J_front + J_back
        
        # right back
        i = np.shape(n_alpha)[1] - 1
        j = 0
        J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
        J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
        J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]
        J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]
            
        J_alpha_UMat[:,i,j,k] = J_left + J_bottom + J_front + J_back
        
        # left front
        i = 0
        j = np.shape(n_alpha)[2] - 1
        J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
        J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
        J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]
        J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]
            
        J_alpha_UMat[:,i,j,k] = J_right + J_top + J_front + J_back
        
        # right front
        i = np.shape(n_alpha)[1] - 1
        j = np.shape(n_alpha)[2] - 1
        J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
        J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
        J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]
        J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]
            
        J_alpha_UMat[:,i,j,k] = J_left + J_top + J_front + J_back
         
        
    # 4th : Deal with the Corners
        # NOTE : we have 2 possible values for each of i,j,k, yielding 2^3 = 8 corners
    # for corner at (0, 0, 0)
    i = 0
    j = 0
    k = 0
    J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
    J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
    J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]   
    J_alpha_UMat[:,i,j,k] = J_right + J_bottom + J_back
    
    # for corner at (0, 0, Na)
    i = 0
    j = 0
    k = np.shape(n_alpha)[3] - 1
    J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
    J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
    J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]   
    J_alpha_UMat[:,i,j,k] = J_right + J_top + J_bottom + J_front
    
    # for corner at (0, Na, 0)
    i = 0
    j = np.shape(n_alpha)[2] - 1
    k = 0
    J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
    J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
    J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]      
    J_alpha_UMat[:,i,j,k] = J_right + J_top + J_back
    
    # for corner at (Na, 0, 0)
    i = np.shape(n_alpha)[1] - 1
    j = 0
    k = 0
    J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
    J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
    J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]
    J_alpha_UMat[:,i,j,k] = J_left + J_bottom + J_back
    
    # for corner at (Na, Na, 0)
    i = np.shape(n_alpha)[1] - 1
    j = np.shape(n_alpha)[2] - 1
    k = 0
    J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
    J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
    J_back = v_alpha[:,i,j,k+1] * n_alpha[:,i,j,k+1] * mu_alpha[:,i,j,k+1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k+1]
    J_alpha_UMat[:,i,j,k] = J_left + J_top + J_back
    
    # for corner at (0, Na, Na)
    i = 0
    j = np.shape(n_alpha)[2] - 1
    k = np.shape(n_alpha)[3] - 1
    J_right = v_alpha[:,i+1,j,k] * n_alpha[:,i+1,j,k] * mu_alpha[:,i+1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i+1,j,k]
    J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
    J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]     
    J_alpha_UMat[:,i,j,k] = J_right + J_top + J_front 
    
    # for corner at (Na, 0, Na)
    i = np.shape(n_alpha)[1] - 1
    j = 0
    k = np.shape(n_alpha)[3] - 1
    J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
    J_bottom = v_alpha[:,i,j+1,k] * n_alpha[:,i,j+1,k] * mu_alpha[:,i,j+1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j+1,k]
    J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]      
    J_alpha_UMat[:,i,j,k] = J_left + J_bottom + J_front
    
    # for corner at (Na, Na, Na)
    i = np.shape(n_alpha)[1] - 1
    j = np.shape(n_alpha)[2] - 1
    k = np.shape(n_alpha)[3] - 1
    J_left = v_alpha[:,i-1,j,k] * n_alpha[:,i-1,j,k] * mu_alpha[:,i-1,j,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i-1,j,k]
    J_top = v_alpha[:,i,j-1,k] * n_alpha[:,i,j-1,k] * mu_alpha[:,i,j-1,k] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j-1,k]
    J_front = v_alpha[:,i,j,k-1] * n_alpha[:,i,j,k-1] * mu_alpha[:,i,j,k-1] / mu_alpha[:,i,j,k] - v_alpha[:,i,j,k] * n_alpha[:,i,j,k] * mu_alpha[:,i,j,k] / mu_alpha[:,i,j,k-1]      
    J_alpha_UMat[:,i,j,k] = J_left + J_top + J_front
    
    return J_alpha_UMat


def n_alpha_update_Forward_3D(dt, Na, n_alpha_Update, n_alpha_Current, n_alpha_Past, J_alpha_UMat):
    
    a = 1/Na # calculate dx
    B_x = np.arange(a/2, 1 - a/2 + 1e-15, a) # create B_x
    
    # initialize n_alpha_Update
    n_alpha_Update = np.zeros(np.shape(n_alpha_Past))

    # NOTE : The 1D J_Present method NOT implemented
                                    # needs to be dt * a
    n_alpha_Update = n_alpha_Current + (dt / a) * J_alpha_UMat
    
    # update the n_alpha's appropriately in preparation for the next iteration
    n_alpha_Past = n_alpha_Current
    n_alpha_Current = n_alpha_Update
    
    return n_alpha_Update, n_alpha_Current, n_alpha_Past


def iteration_Forward_3D(dt, i_glob, Na, T, k_B, A_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1):
    
    # update rho
    rho = rho_update_3D(Na, n_alpha_Current, q_alpha)
    
    # update phi
    phi = phi_update_3D(Na, A_matrix, rho, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)
    
    # update mu_alpha & v_alpha, N O T E : combined mu_alpha_update_1D and v_alpha_update_1D into ONE function
    mu_alpha, v_alpha = mu_and_v_alpha_update_3D(Na, T, k_B, mu_bar_alpha, q_alpha, phi, D_alpha)
    
    # update J_alpha
    J_alpha_UMat = J_alpha_update_3D(Na, T, k_B, mu_alpha, v_alpha, n_alpha_Current)
    
    # update n_alpha
    n_alpha_Update, n_alpha_Current, n_alpha_Past = n_alpha_update_Forward_3D(dt, Na, n_alpha_Update, n_alpha_Current, n_alpha_Past, J_alpha_UMat)
   
    return n_alpha_Update, n_alpha_Current, n_alpha_Past


def simulation_Forward_3D(dt, tmax, Na, T, k_B, n_alpha_Update, n_alpha_Current, n_alpha_Past, q_alpha, mu_bar_alpha, D_alpha, plotting = False): # dt, Na, B_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1
    
    i_glob = 0 # global iteration counter (specifically for 1st timestep's n'(x, t) calculation)
    t_cur = 0.0  # global time counter
    
    a = 1/Na # calculate dx
    
    A_x = np.arange(0, 1 + 1e-15, a)         # length of Na + 1
    B_x = np.arange(a/2, 1 - a/2 + 1e-15, a) # length of Na
    
    # initialize 
    n_alpha_Update = np.zeros((len(B_x), 1))
    n_plotting = np.array([])
    
    # construct the Poisson 1D discretization matrix B
    A_matrix = poisson_matrix_3D(Na, ghosts_included = True)
    
    # start plotting/animating
    fig = plt.figure() # initialize figure
    axis = plt.axes(xlim =(0, 1), ylim =(-2, 10)) # marking the x-axis and y-axis 
    line, = axis.plot([], [], lw = 3) # initializing a line variable 
    plt.close() # to not have a stray plot
    
    # data which the line will 
    # contain (x, y) 
    def init(): 
        line.set_data([], []) 
        return line, 
    
    def animate(i): 
        x = np.arange(a/2, 1 - a/2 + 1e-15, a) # set the x axis to B_x

        if (i < int(tmax/dt - 1e-15)):
            
            n_plot = n_plot_matrix[i,:] # extract the i^th row for plotting
        
            line.set_data(x, n_plot) 
            
        else:
            
            return line,
      
        return line,
    
    
    while (t_cur < tmax):
        
        n_alpha_Update, n_alpha_Current, n_alpha_Past = iteration_Forward_3D(dt, i_glob, Na, T, k_B, A_matrix, q_alpha, n_alpha_Update, n_alpha_Current, n_alpha_Past, mu_bar_alpha, D_alpha, ghosts_included = True, epsilon_0 = 1, epsilon_r = 1)
        
        if (plotting):
            
            n_plotting = np.append(n_plotting, n_alpha_Update)
                     
        i_glob += 1
        t_cur += dt
        
    if (plotting):
        
        n_plot_matrix = n_plotting.reshape((int(tmax/dt - 1e-15) + 1, len(B_x))) # every row corresponds to N_alpha 
                                                                 # at a different time-step  
        anim = FuncAnimation(fig, animate, init_func = init, frames = 500, interval = 20, blit = True)
        
        #return HTML(anim.to_jshtml())
        
        return anim
    
    else:
        
        print('\nSimulation completed at time', t_cur, '!!!')
        
        return n_alpha_Current, t_cur