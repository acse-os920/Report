print("Welcome to 1D CPFM simulation testing and validation. ")

from IPython import display
import numpy as np
import scipy.sparse
import matplotlib.pyplot as plt
from matplotlib import cm
import scipy.sparse.linalg
import math

# import the cpfm_1D.py functions
import cpfm_1D as cpfm

########################################################################################################
# TEST 1 : Pure Diffusion, Qualitative Analysis #
########################################################################################################

def diffusion_1D_analytical(Na, t, D = 0.01, n_i_amp = 10.0):
    """
    Creates an analytical solution for n_alpha at the specified time
    Input: Na (int), number of grid points
           t (float), the time of the solution, equal to t_final 
                of the simulation for comparison purposes
           D (float), diffusion constant
           n_i_amp (float), initial average n_alpha amplitude
    Output: n_Analytical (float array), (Na) x 1 analytical n_alpha(t) solution
    """
    
    a = 1.0/Na # dx
    x_ar = np.arange(a/2, 1 - a/2 + 1e-15, a) # identical to B_x 
    L = x_ar[-1] - x_ar[0]
    
    n_Analytical = np.zeros((Na, 1))
    
    n_i_avg = n_i_amp/Na
    
    for i in range(len(x_ar)):
        
        n_Analytical[i] = (n_i_avg * L / np.sqrt(4 * np.pi * D * t)) * np.exp(-(x_ar[i]-0.5)**2 / (4 * D * t))
        
    return n_Analytical 


def test_1():
    
    # Initialize variables for testing conditions
    Na = 51
    T = 300
    k_B = 1e-2
    t_max = 0.1
    a = 1.0/Na
    dt = a**2
    x_ax = np.arange(a/2, 1 - a/2 + 1e-15, a)

    q_alpha = np.array([0])
    # Forward Euler temporal discretization
    n_alpha_Update_FE = np.zeros((Na,1))
    n_alpha_Current_FE = np.zeros((Na,1))
    n_alpha_Current_FE[int((Na-1)/2)] = 10.0
    n_alpha_Past_FE = np.zeros((Na,1))
    # Backward Euler temporal discretization
    n_alpha_Update_BE = np.zeros((Na,1))
    n_alpha_Current_BE = np.zeros((Na,1))
    n_alpha_Current_BE[int((Na-1)/2)] = 10.0
    n_alpha_Past_BE = np.zeros((Na,1))
    n_alpha_Past_BE[int((Na-1)/2)] =  10.0
    mu_bar_alpha = np.zeros((Na,1)) 
    D_alpha = 1e-1 * np.ones((Na,1))

    # Store the 1D n_alpha array for plotting
    n_CPFM_1D_forward, t_sim_finalized_FE = cpfm.simulation_Forward_1D(dt, t_max, Na, T, k_B, n_alpha_Update_FE, n_alpha_Current_FE, n_alpha_Past_FE, q_alpha, mu_bar_alpha, D_alpha, plotting = False)
    
    n_CPFM_1D_backward, t_sim_finalized_BE = cpfm.simulation_Backward_1D(dt, t_max, Na, T, k_B, n_alpha_Update_BE, n_alpha_Current_BE, n_alpha_Past_BE, q_alpha, mu_bar_alpha, D_alpha, plotting = False)
   
    # Create the analytical n_alpha solution 
    n_Analytical = diffusion_1D_analytical(Na, t_sim_finalized_FE, D = D_alpha[0][0], n_i_amp = 10.0)

    labels = ['Analytical Solution', '1D CPFM Solution (Forward)', '1D CPFM Solution (Backward)'] #, '1D CPFM Solution (Mixed)']

    # Plot
    fig, (ax1, ax2, ax3, ax4) = plt.subplots(4, 1, sharex = True, figsize=(10, 20))
    ax1.plot(x_ax, n_Analytical, x_ax, n_CPFM_1D_forward, x_ax, n_CPFM_1D_backward)
    ax1.set_xlabel(r'Horizontal Domain, $x \in [0, 1]$')
    ax1.set_ylabel(r'Number of Particles, $n_\alpha$')
    ax1.set_title('Pure Diffusion - Qualitative Analysis')
    ax1.legend(labels)
    ax2.plot(x_ax, np.abs(n_CPFM_1D_forward - n_Analytical), x_ax, np.abs(n_CPFM_1D_backward - n_Analytical))
    ax2.set_xlabel(r'Horizontal Domain, $x \in [0, 1]$')
    ax2.set_ylabel(r'Absolute Error, $e_{abs} = | n_{Analytical} - n_{CPFM, 1D} |$')
    ax2.set_title('Pure Diffusion - Absolute Error')
    ax2.legend(labels[1:])
    ax3.plot(x_ax, (n_CPFM_1D_forward - n_Analytical), x_ax, (n_CPFM_1D_backward - n_Analytical))
    ax3.set_xlabel(r'Horizontal Domain, $x \in [0, 1]$')
    ax3.set_ylabel(r'Error, $e_{abs} = n_{CPFM, 1D} - n_{Analytical} $')
    ax3.set_title('Pure Diffusion - Error')
    ax3.legend(labels[1:])

    ax4.plot(x_ax, n_CPFM_1D_backward)

    # Calculate Errors
    error_FE_L1 = a * np.sum(np.abs(n_CPFM_1D_forward - n_Analytical))
    error_FE_L2 = a * np.sqrt(np.sum((n_CPFM_1D_forward - n_Analytical)**2))
    error_FE_RMS = np.sqrt(a * np.sum((n_CPFM_1D_forward - n_Analytical)**2))
    error_BE_L1 = a * np.sum(np.abs(n_CPFM_1D_backward - n_Analytical))
    error_BE_L2 = a * np.sqrt(np.sum((n_CPFM_1D_backward - n_Analytical)**2))
    error_BE_RMS = np.sqrt(a * np.sum((n_CPFM_1D_backward - n_Analytical)**2))

    # Print information for user
    print('Simulation Information : Na =', Na, ', dx =', a, ', dt =', dt, ', D =', D_alpha[0][0], ', t_max =', t_max)
    print('\nFE L1 error =', error_FE_L1)
    print('FE L2 error =', error_FE_L2)
    print('FE RMS error =', error_FE_RMS)
    print('\nBE L1 error =', error_BE_L1)
    print('BE L2 error =', error_BE_L2)
    print('BE RMS error =', error_BE_RMS)

    return fig #plt.plot(x_ax, n_Analytical, x_ax, n_CPFM_1D_forward)


########################################################################################################

options = ['Pure Diffusion, Qualitative Analysis', 'Pure Diffusion, Error Convergence Analysis w.r.t. dx', 'Pure Diffusion, Error Convergence Analysis w.r.t. dt']

print('\nYou have the following options:\n')

for option_counter in range(len(options)):

    print((option_counter + 1), ':', options[option_counter])

user_choice = -1

while (user_choice < 0):
    
    user_choice = int(input('Please enter the number of the option you want to choose :'))

    if ((user_choice == 1) or (user_choice == 2) or (user_choice == 3)):
        print('\n', options[user_choice - 1], ': starting...') 
    
    else: 
        print('\nPlease enter a valid number ...')
        user_choice = -1







if (user_choice == 1):

    test_1()









# def diffusion_1D_analytical(Na, t, D = 0.1, n_i_amp = 10.0):
    
#     a = 1.0/Na # dx
#     x_ar = np.arange(a/2, 1 - a/2 + 1e-15, a) # identical to B_x 
#     L = x_ar[-1] - x_ar[0]
    
#     n_Analytical = np.zeros((Na, 1))
    
#     n_i_avg = n_i_amp/Na
    
#     for i in range(len(x_ar)):
        
#         n_Analytical[i] = (n_i_avg * L / np.sqrt(4 * np.pi * D * t)) * np.exp(-(x_ar[i]-0.5)**2 / (4 * D * t))
        
#     return n_Analytical 


# n_an = diffusion_1D_analytical(Na, 0.125, D = 0.1, n_i_amp = 10)
 
# a = 1.0/Na # dx
# x_ar = np.arange(a/2, 1 - a/2 + 1e-15, a) # identical to B_x 
# L = x_ar[-1] - x_ar[0]

# plt.plot(x_ar, n_an, x_ar, amez)
# plt.legend(['Analytical', 'CPFM'])